
<!DOCTYPE html>
<html>
<head>
    <title>Tutorial Membuat Pagination Pada Laravel - www.malasngoding.com</title>
</head>
<body>

    <style type="text/css">
        .pagination li{
            float: left;
            list-style-type: none;
            margin:5px;
        }
    </style>

    <h2><a href="#">TEST</a></h2>
    <h3>Data Pegawai</h3>


    <table border="1">
        <tr>
            <th>Nama</th>
            <th>Jabatan</th>
            <th>Umur</th>
            <th>Alamat</th>
        </tr>
        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->pegawai_nama); ?></td>
            <td><?php echo e($p->pegawai_jabatan); ?></td>
            <td><?php echo e($p->pegawai_umur); ?></td>
            <td><?php echo e($p->pegawai_alamat); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <br/>
    Halaman : <?php echo e($pegawai->currentPage()); ?> <br/>
    Jumlah Data : <?php echo e($pegawai->total()); ?> <br/>
    Data Per Halaman : <?php echo e($pegawai->perPage()); ?> <br/>


    <?php echo e($pegawai->links()); ?>



</body>
</html>